name = input("enter your name : ")
name = "sudhot"
env = "dev"
print("Hello ",name)