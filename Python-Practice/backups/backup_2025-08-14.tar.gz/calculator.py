num1 = int(input("Enter 1st number : "))
num2 = int(input("Enter 2nd number : "))

sum = num1 + num2
print("Sum of two numbers : ",sum)
diff = num1 - num2
print("Diff of two numbers : ",diff)
product = num1 * num2
print("Product of two numbers : ",product)
div = num1 / num2
print("Div of two numbers : ",div)